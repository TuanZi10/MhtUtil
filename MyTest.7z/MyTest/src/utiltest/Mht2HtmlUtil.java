package utiltest;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.util.Enumeration;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
public class Mht2HtmlUtil {

	public static void main(String[] args) throws IOException {
        /**
         *  ת��
         */
        //mht2html("f:\\job_111.mht", "f:\\test.htm");   
        

        /**
         *  ��ȡ�������Ա�
         */
        String nameAndSex = Mht2HtmlUtil.findResultValue("f:\\test.htm", "li", "info_name");
        
        String tmpString = nameAndSex.replaceAll("(?i)[^a-zA-Z0-9\u4E00-\u9FA5]", "");// ȥ��������Ӣ�ķ���
        char[] carr = tmpString.toCharArray();
        for (int i = 0; i < tmpString.length(); i++) {
            if (carr[i] < 0xFF) {
                carr[i] = ' ';// ���˵��Ǻ�������
            }
        }
        System.out.println(tmpString.substring(0, tmpString.length()-1)); //����
        System.out.println(tmpString.substring(tmpString.length()-1)); //�Ա�
        
        /**
         * ��ȡ��������
         */
        File htmlf=new File("f:\\test.htm");
        Document doc=Jsoup.parse(htmlf, "UTF-8"); 
        String ss=doc.body().toString(); 
       //class����masthead��li��ǩ
        Object[] aa= doc.select("div.detaile_box").toArray();
        for (int i = 0; i < aa.length; i++) {
            if(i==3){
                String strtext = aa[i].toString();
                Document docs = Jsoup.parse(strtext);
                Object[] bb= docs.select("b.edu_main_sch").toArray();
                for (int j = 0; j < bb.length; j++) {
                    String tt = bb[j].toString();
                    Document doct = Jsoup.parse(tt);
                    String result = doct.select("b.edu_main_sch").text();
                    String a=result.substring(0, result.indexOf("|")).trim();
                    String b=result.substring(result.lastIndexOf("|")+1, result.length()).trim();
                    System.out.println(a+"    "+b);  //��ҵԺУ��ѧ��
                    
                }
            }
            
        }
        
    }
    
    
    /**
     * ������ǩ  ��ȡ��ǩֵ
     * @param htmlFilePath          �ļ�·��   
     * @param lableName              ��ǩ����
     * @param onClassName            ��ǩ����
     * @return
     * @throws IOException 
     */
    public static String findResultValue(String htmlFilePath , String lableName , String onClassName) throws IOException{
        File htmlf=new File(htmlFilePath);
        Document doc=Jsoup.parse(htmlf, "UTF-8");
        String bodyText=doc.body().toString();  // ��ȡ�ļ��ı���Ϣ
        //class����onClassName��lableName��ǩ
        String  resultValue = doc.select(lableName+"."+onClassName).first().text();
        
        return resultValue;
    }
    
    /**
     * ������ǩ������ض��ֵ
     * @param htmlFilePath          �ļ�·��   
     * @param lableName              ��ǩ����
     * @param onClassName            ��ǩ����
     * @return
     * @throws IOException 
     */
    public static Object[]  findResultValueToArray (String htmlFilePath , String lableName , String onClassName) throws IOException{
        File htmlf=new File(htmlFilePath);
        Document doc=Jsoup.parse(htmlf, "UTF-8");
        String bodyText=doc.body().toString();  // ��ȡ�ļ��ı���Ϣ
        return doc.select(lableName+"."+onClassName).toArray();
    }
    
    /**
     * �� mht�ļ�ת���� html�ļ�
     * 
     * @param s_SrcMht      // mht �ļ���λ��
     * @param s_DescHtml    // ת���������HTML��λ��
     */
    public static void mht2html(String srcMht, String descHtml) {
        try {
            InputStream fis = new FileInputStream(srcMht);
            Session mailSession = Session.getDefaultInstance(
                    System.getProperties(), null);
            MimeMessage msg = new MimeMessage(mailSession, fis);
            Object content = msg.getContent();
            if (content instanceof Multipart) {
                MimeMultipart mp = (MimeMultipart) content;
                MimeBodyPart bp1 = (MimeBodyPart) mp.getBodyPart(0);
 
                // ��ȡmht�ļ����ݴ���ı���
                String strEncodng = getEncoding(bp1);
 
                // ��ȡmht�ļ�������
                String strText = getHtmlText(bp1, strEncodng);
                if (strText == null)
                    return;
 
                /**
                 *  ������mht�ļ����Ƶ��ļ��У���Ҫ����������Դ�ļ���  ���ﲻ��Ҫ����ע�͵���
                 */
/*                File parent = null;
                if (mp.getCount() > 1) {
                    parent = new File(new File(descHtml).getAbsolutePath()
                            + ".files");
                    parent.mkdirs();
                    if (!parent.exists()) { // �����ļ���ʧ�ܵĻ����˳�
                        return;
                    }
                }*/
 
                /**
                 *  FOR�д��� ��Ҫ�Ǳ�����Դ�ļ����滻·��    ���ﲻ��Ҫ����ע�͵���
                 */
/*                for (int i = 1; i < mp.getCount(); ++i) {
                    MimeBodyPart bp = (MimeBodyPart) mp.getBodyPart(i);
                    // ��ȡ��Դ�ļ���·��
                    // ������ȡ�� http://xxx.com/abc.jpg��
                    String strUrl = getResourcesUrl(bp);
                    if (strUrl == null || strUrl.length() == 0)
                        continue;
 
                    DataHandler dataHandler = bp.getDataHandler();
                    MimePartDataSource source = (MimePartDataSource) dataHandler
                            .getDataSource();
 
                    // ��ȡ��Դ�ļ��ľ���·��
                    String FilePath = parent.getAbsolutePath() + File.separator
                            + getName(strUrl, i);
                    File resources = new File(FilePath);
 
                    // ������Դ�ļ�
                    if (SaveResourcesFile(resources, bp.getInputStream())) {
                        // ��Զ�̵�ַ�滻Ϊ���ص�ַ ��ͼƬ��JS��CSS��ʽ�ȵ�
                        strText = strText.replace(strUrl,
                                resources.getAbsolutePath());
                    }
                }*/
 
                // ��󱣴�HTML�ļ�
                SaveHtml(strText, descHtml, strEncodng);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
 
    /**
     * ��ȡmht�ļ���������Դ�ļ�������
     * 
     * @param strName
     * @param ID
     * @return
     */
    public static String getName(String strName, int ID) {
        char separator1 = '/';
        char separator2 = '\\';
        // �������滻
        strName = strName.replaceAll("\r\n", "");
 
        // ��ȡ�ļ�����
        if (strName.lastIndexOf(separator1) >= 0) {
            return strName.substring(strName.lastIndexOf(separator1) + 1);
        }
        if (strName.lastIndexOf(separator2) >= 0) {
            return strName.substring(strName.lastIndexOf(separator2) + 1);
        }
        return "";
    }
 
    /**
     * ����ȡ������html����д�뱣���·���С�
     * 
     * @param strText
     * @param strHtml
     * @param strEncodng
     */
    public static boolean SaveHtml(String s_HtmlTxt, String s_HtmlPath,
            String s_Encode) {
        try {
            Writer out = null;
            out = new OutputStreamWriter(
                    new FileOutputStream(s_HtmlPath, false), s_Encode);
            out.write(s_HtmlTxt);
            out.close();
        } catch (Exception e) {
            return false;
        }
        return true;
    }
 
    /**
     * ������ҳ�е�JS��ͼƬ��CSS��ʽ����Դ�ļ�
     * 
     * @param SrcFile
     *            Դ�ļ�
     * @param inputStream
     *            ������
     * @return
     */
    private static boolean SaveResourcesFile(File SrcFile,
            InputStream inputStream) {
        if (SrcFile == null || inputStream == null) {
            return false;
        }
 
        BufferedInputStream in = null;
        FileOutputStream fio = null;
        BufferedOutputStream osw = null;
        try {
            in = new BufferedInputStream(inputStream);
            fio = new FileOutputStream(SrcFile);
            osw = new BufferedOutputStream(new DataOutputStream(fio));
            int index = 0;
            byte[] a = new byte[1024];
            while ((index = in.read(a)) != -1) {
                osw.write(a, 0, index);
            }
            osw.flush();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (osw != null)
                    osw.close();
                if (fio != null)
                    fio.close();
                if (in != null)
                    in.close();
                if (inputStream != null)
                    inputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }
    }
 
    /**
     * ��ȡmht�ļ�����Դ�ļ���URL·��
     * 
     * @param bp
     * @return
     */
    private static String getResourcesUrl(MimeBodyPart bp) {
        if (bp == null) {
            return null;
        }
        try {
            Enumeration list = bp.getAllHeaders();
            while (list.hasMoreElements()) {
                javax.mail.Header head = (javax.mail.Header) list.nextElement();
                if (head.getName().compareTo("Content-Location") == 0) {
                    return head.getValue();
                }
            }
            return null;
        } catch (MessagingException e) {
            return null;
        }
    }
 
    /**
     * ��ȡmht�ļ��е����ݴ���
     * 
     * @param bp
     * @param strEncoding
     *            ��mht�ļ��ı���
     * @return
     */
    private static String getHtmlText(MimeBodyPart bp, String strEncoding) {
        InputStream textStream = null;
        BufferedInputStream buff = null;
        BufferedReader br = null;
        Reader r = null;
        try {
            textStream = bp.getInputStream();
            buff = new BufferedInputStream(textStream);
            r = new InputStreamReader(buff, strEncoding);
            br = new BufferedReader(r);
            StringBuffer strHtml = new StringBuffer("");
            String strLine = null;
            while ((strLine = br.readLine()) != null) {
                System.out.println(strLine);
                strHtml.append(strLine + "\r\n");
            }
            br.close();
            r.close();
            textStream.close();
            return strHtml.toString();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (br != null)
                    br.close();
                if (buff != null)
                    buff.close();
                if (textStream != null)
                    textStream.close();
            } catch (Exception e) {
            }
        }
        return null;
    }
 
    /**
     * ��ȡmht��ҳ�ļ������ݴ���ı���
     * 
     * @param bp
     * @return
     */
    private static String getEncoding(MimeBodyPart bp) {
        if (bp == null) {
            return null;
        }
        try {
            Enumeration list = bp.getAllHeaders();
            while (list.hasMoreElements()) {
                javax.mail.Header head = (javax.mail.Header) list.nextElement();
                if (head.getName().equalsIgnoreCase("Content-Type")) {
                    String strType = head.getValue();
                    int pos = strType.indexOf("charset=");
                    if (pos >= 0) {
                        String strEncoding = strType.substring(pos + 8,
                                strType.length());
                        if (strEncoding.startsWith("\"")
                                || strEncoding.startsWith("\'")) {
                            strEncoding = strEncoding.substring(1,
                                    strEncoding.length());
                        }
                        if (strEncoding.endsWith("\"")
                                || strEncoding.endsWith("\'")) {
                            strEncoding = strEncoding.substring(0,
                                    strEncoding.length() - 1);
                        }
                        if (strEncoding.toLowerCase().compareTo("gb2312") == 0) {
                            strEncoding = "gbk";
                        }
                        return strEncoding;
                    }
                }
            }
        } catch (MessagingException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    /**
     * ɾ��ָ���ļ�
     * @param filePath  �ļ�·�� 
     * @param fileName  �ļ�����
     * @param layout    �ļ���ʽ 
     */
    public static void deleteFileName(String filePath , String fileName , String layout){
        
        File folder = new File(filePath);
        String fileNameOnLayout=fileName+"."+layout;
        File[] files = folder.listFiles(); //��ȡ���ļ����µ������ļ�
        for(File file:files){              
            if(file.getName().equals(fileNameOnLayout)){
                file.delete();
            }
        }
        
    }
}
