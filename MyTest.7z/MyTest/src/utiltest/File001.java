package utiltest;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public class File001 {
	public static void main(String[] args) throws IOException {
		
		Date date = new Date(System.currentTimeMillis());
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		String fileName = simpleDateFormat.format(date);
		
		String content = "Hello World !";
		String content1 = "Hello World !";
		String path = "C:\\\\Temp";
		String name = fileName+".txt";
		
		JFileChooser fileChooser = new JFileChooser("D:\\"); 
		 fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY); 
		 fileChooser.setDialogTitle("��ѡ����Ҫ������ļ���");
		 int returnVal = fileChooser.showOpenDialog(fileChooser); 
		 String filePath= fileChooser.getSelectedFile().getAbsolutePath();
		
		File file = new File(filePath,name);
		if (file.exists()) {
			file.delete();
		}
		file.createNewFile();
		for(int i=0 ;i<9;i++) {
		Files.write(Paths.get(file.getAbsolutePath()), (content+ "\n").getBytes(),StandardOpenOption.CREATE,StandardOpenOption.APPEND);
		}
		JOptionPane.showMessageDialog(null, "������ϣ��ļ�"+file.getName()+"�ѱ�����"+filePath);
		
		
	}
}
