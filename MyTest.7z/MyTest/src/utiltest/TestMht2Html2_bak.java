package utiltest;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

public class TestMht2Html2_bak {

	public static void main(String[] args) throws IOException {
//		String src = "C:\\Temp\\����_58ͬ�Ǽ���.mht";
//		String des = "C:\\Temp\\test2.html";
//		Mht2HtmlUtil.mht2html(src, des);
//      String tel = Mht2HtmlUtil.findResultValue(des, "span", "ored");
//      String name = Mht2HtmlUtil.findResultValue(des, "span", "name");
//      String sexAge = Mht2HtmlUtil.findResultValue(des, "span", "sexAge");
//      
//      String age = sexAge.substring(3, 5);
//      String sex = sexAge.substring(1, 2);
//      
//      System.out.println(name+" "+age+" "+sex+" "+tel);
      
		String des = "C:\\Temp\\test2.html";
//		File tempfile = Files.createFile("C:\\\\Temp\\\\", test002.txt);
        String path = "C:\\Temp\\Test";		//Ҫ������·��
		File file = new File(path);		//��ȡ��file����
		File[] fs = file.listFiles();	//����path�µ��ļ���Ŀ¼������File������
		for(File f:fs){					//����File[]����
			if(f.getName().endsWith("mht")) {
		      Mht2HtmlUtil.mht2html(f.getAbsolutePath(), des);
			  String tel = Mht2HtmlUtil.findResultValue(des, "span", "ored");
		      String name = Mht2HtmlUtil.findResultValue(des, "span", "name");
		      String sexAge = Mht2HtmlUtil.findResultValue(des, "span", "sexAge");
		      String age = sexAge.substring(3, 5);
		      String sex = sexAge.substring(1, 2);
		      String cc = name+","+age+","+sex+","+tel;
				Files.write(Paths.get("C:\\\\Temp\\\\test002.txt"), (cc+ "\n").getBytes(),StandardOpenOption.CREATE,StandardOpenOption.APPEND);
			}
	      }
	}	
}
	

		
	


