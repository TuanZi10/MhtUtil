package utiltest;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;

import com.spire.pdf.*;

public class Pdf2Text {
	public static void main(String[] args) throws FileNotFoundException {
//        String inputFile = "C:\\\\Temp\\\\������Ƹ_����_���³�Ƹ�չ�_����_20200302_1583129951849.pdf";
//        String outputFile = "C:\\\\Temp\\\\result.html";
//
//      //Open pdf document
//        PdfDocument pdf = new PdfDocument();
//        pdf.loadFromFile(inputFile);
//
//        //Convert to stream
//        File outFile = new File(outputFile);
//        OutputStream outputStream = new FileOutputStream(outFile);
//        pdf.saveToStream(outputStream, FileFormat.HTML);
//        pdf.close();
		
		//����PdfDocumentʵ��
        PdfDocument doc= new PdfDocument();
      //����PDF�ļ�
        doc.loadFromFile("C:\\\\Temp\\\\������Ƹ_�½���_���³�Ƹ�չ�_����_20200302_1583129897090.pdf");       

        StringBuilder sb= new StringBuilder();
        PdfPageBase page;
      //����PDFҳ�棬��ȡ�ı�
//        for(int i=0;i<doc.getPages().getCount();i++){
//        	page=doc.getPages().get(i);
//            sb.append(page.extractText(true));
//        }
        page=doc.getPages().get(0);
        sb.append(page.extractText(true));
        
        FileWriter writer;
        try {
        	//���ı�д���ı��ļ�
        	writer = new FileWriter("C:\\\\Temp\\\\ExtractText.txt"); 
        	writer.write(sb.toString());
        	System.out.println(sb.toString());
        	writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
         }
        doc.close();	
    }
}
