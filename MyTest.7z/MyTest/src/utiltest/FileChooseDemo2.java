package utiltest;

import javax.swing.JFileChooser;

public class FileChooseDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		JFileChooser fileChooser = new JFileChooser("D:\\"); 

		 fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY); 
		 fileChooser.setDialogTitle("��ѡ����Ҫ�������ļ���");

		 int returnVal = fileChooser.showOpenDialog(fileChooser); 
		 

//		 if(returnVal == JFileChooser.APPROVE_OPTION){ 
//			 String filePath= fileChooser.getSelectedFile().getAbsolutePath();
//			 System.out.println(filePath);
//		}
		 String filePath= fileChooser.getSelectedFile().getAbsolutePath();
		 System.out.println(filePath);
	}

}
