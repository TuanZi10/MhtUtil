package utiltest;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public class TestMht2Html {

	public static void main(String[] args) throws IOException {
		Date date = new Date(System.currentTimeMillis());
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		String fileName = simpleDateFormat.format(date);
		String randomFileName = fileName+".txt";
		
		String des = "C:\\Temp\\test2.html";
//        String path = "C:\\Temp\\Test";		//Ҫ������·��
        
		 JFileChooser fileChooser = new JFileChooser(); 
		 fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY); 
		 fileChooser.setDialogTitle("��ѡ����Ҫ�������ļ���");
		 int returnVal = fileChooser.showOpenDialog(fileChooser); 
		 File file = fileChooser.getSelectedFile();		//��ȡ��file����
		 
		File[] fs = file.listFiles();	//����path�µ��ļ���Ŀ¼������File������
		
		JFileChooser fileChooser2 = new JFileChooser("D:\\"); 
		 fileChooser2.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY); 
		 fileChooser2.setDialogTitle("��ѡ����Ҫ������ļ���");
		 int returnVal2 = fileChooser2.showOpenDialog(fileChooser); 
		 String filePath= fileChooser2.getSelectedFile().getAbsolutePath();
		File file2 = new File(filePath,randomFileName);
		file2.createNewFile();

		for(File f:fs){					//����File[]����
			if(f.getName().endsWith("mht")) {
		      Mht2HtmlUtil.mht2html(f.getAbsolutePath(), des);
			  String tel = Mht2HtmlUtil.findResultValue(des, "span", "ored");
		      String name = Mht2HtmlUtil.findResultValue(des, "span", "name");
		      String sexAge = Mht2HtmlUtil.findResultValue(des, "span", "sexAge");
		      String age = sexAge.substring(3, 5);
		      String sex = sexAge.substring(1, 2);
		      String cc = name+","+age+","+sex+","+tel;
			 Files.write(Paths.get(file2.getAbsolutePath()), (cc+ "\n").getBytes(),StandardOpenOption.CREATE,StandardOpenOption.APPEND);
			}
	      }
		JOptionPane.showMessageDialog(null, "������ϣ��ļ�"+file2.getName()+"�ѱ�����"+filePath);
	}	
}
	

		
	


